# Bingo Asteria Perú - PRO

Instrucciones rápidas:

1. Coloca tu logo final en public/assets/logo.png (ya hay un placeholder).
2. En terminal:
   npm install
   npm start
3. Abre http://localhost:3000

Notas:
- El sistema usa Web Speech API para voz (funciona en navegadores modernos).
- Para producción puedes desplegar en un VPS o servicios como Render, Vercel (frontend) + Heroku/Render (server).
